In such circumstances of this highly life-threatening pandemic affecting the whole world, one needs to be well informed in order to fight Covid-19. Keeping this in mind, this idea is being presented to develop a web app which would help the people to track corona.

This tracker would tell the people about the current status of Corona Spread in the world using a graphical representation.

This web app consists of 3 components, namely, Cards to represent the currently infected, deaths and recovered patients.
The second component is the country picker that would enable the user to select the country whose current scenario of corona spread needs o be viewed.
The third component is the Chart that is made using Chart.Js, an exquisite feature of React to view the graphical representation of the 
data.